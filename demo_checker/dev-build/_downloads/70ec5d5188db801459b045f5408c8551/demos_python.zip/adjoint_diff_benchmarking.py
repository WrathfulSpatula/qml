r"""

.. _adjoint_differentiation_benchmarking:

Adjoint Differentiation
=======================

.. meta::
    :property="og:description": Benchmarking file for adjoint diff demonstration.
    :property="og:image": https://pennylane.ai/qml/_static/thumbs/code.png


*Author: Christina Lee — Posted: 23 November 2021. Last updated: 23 November 2021.*

"""

##############################################################################
# This page is supplementary material to the
# `Adjoint Differentiation <https://pennylane.ai/qml/demos/tutorial_adjoint_diff.html>`__
# demonstration.  The below script produces the benchmarking images used.




















































































































##############################################################################
#
# .. figure:: ../demonstrations/adjoint_diff/scaling.png
#     :width: 80%
#     :align: center
#
#
# About the author
# ----------------
# .. include:: ../_static/authors/christina_lee.txt