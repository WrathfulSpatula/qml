r"""

.. _general_parshift:

Generalized parameter-shift rules
=================================

.. meta::

    :property="og:description": Reconstruct quantum functions and compute their derivatives.
    :property="og:image": https://pennylane.ai/qml/_images/thumbnail_genpar.png

.. related::

   tutorial_expressivity_fourier_series Quantum models as Fourier series
   tutorial_rotoselect Quantum circuit structure learning
   tutorial_quantum_analytic_descent Quantum analytic descent


*Author: David Wierichs (Xanadu Resident) — Posted: 23 August 2021. Last updated: 27 August 2021*

In this demo we will look at univariate quantum functions, i.e., those that
depend on a single parameter. We will investigate the form such functions usually take
and demonstrate how we can *reconstruct* them as classical functions, capturing the full
dependence on the input parameter.
Once we have this reconstruction, we use it to compute analytically exact derivatives
of the quantum function. We implement this in two ways:
first, by using autodifferentiation on the classical function that is produced by the 
reconstruction, which is flexible with respect to the degree of the derivative.
Second, by computing the derivative manually, resulting in generalized parameter-shift
rules for quantum functions that is more efficient (regarding classical cost) than the 
autodifferentiation approach, but requires manual computations if we want to access
higher-order derivatives.
All we will need for the demo is the insight that these functions are Fourier series in their
variable, and the reconstruction itself is a
`trigonometric interpolation <https://en.wikipedia.org/wiki/Trigonometric_interpolation>`_.

A full description of the reconstruction, the technical derivation of the parameter-shift
rules, and considerations for multivariate functions can be found in the paper
`General parameter-shift rules for quantum gradients <https://arxiv.org/abs/2107.12390>`_
[#GenPar]_.
The core idea to consider these quantum functions as Fourier series was first presented in
the preprint
`Calculus on parameterized quantum circuits <https://arxiv.org/abs/1812.06323>`_ [#CalcPQC]_.
We will follow [#GenPar]_, but there also are two preprints discussing general parameter-shift
rules: an algebraic approach in
`Analytic gradients in variational quantum algorithms: Algebraic extensions of the parameter-shift rule to general unitary transformations <https://arxiv.org/abs/2107.08131>`_ [#AlgeShift]_
and one focusing on special gates and spectral decompositions, namely
`Generalized quantum circuit differentiation rules <https://arxiv.org/abs/2108.01218>`_
[#GenDiffRules]_.

|

.. figure:: ../demonstrations/general_parshift/thumbnail_genpar.png
    :align: center
    :width: 50%
    :target: javascript:void(0)

    Function reconstruction and differentiation via parameter shifts.

.. note ::

    Before going through this tutorial, we recommend that readers refer to the
    :doc:`Fourier series expressiveness tutorial </demos/tutorial_expressivity_fourier_series>`.
    Additionally, having a basic understanding of the
    :doc:`parameter-shift rule </glossary/parameter_shift>` might make this tutorial easier
    to dive into.

Cost functions arising from quantum gates
-----------------------------------------
We start our investigation by considering a cost function that arises from measuring the expectation
value of an observable in a quantum state, created with a parametrized quantum operation
that depends on a single variational parameter :math:`x`.
That is, the state may be prepared by any circuit, but we will only allow a single parameter
in a single operation to enter the circuit.
For this we will use a handy gate structure that allows us to tune the complexity of the
operation — and thus of the cost function.
More concretely, we initialize a qubit register in a random state :math:`|\psi\rangle`
and apply a layer of Pauli-:math:`Z` rotations ``RZ`` to all qubits, where all rotations are parametrized by the *same* angle :math:`x`.
We then measure the expectation value of a random Hermitian observable :math:`B` in the created
state, so that our cost function overall has the form

.. math ::

  E(x)=\langle\psi | U^\dagger(x) B U(x)|\psi\rangle.

Here, :math:`U(x)` consists of a layer of ``RZ`` gates,

.. math ::

  U(x)=\prod_{a=1}^N R_Z^{(a)}(x) = \prod_{a=1}^N \exp\left(-i\frac{x}{2} Z_a\right).

Let's implement such a cost function using PennyLane.
We begin with functions that generate the random initial state :math:`|\psi\rangle`
and the random observable :math:`B` for a given number of qubits :math:`N` and a fixed seed:
"""






















###############################################################################
# Now let's set up a "cost function generator", namely a function that will create the
# ``cost`` function we discussed above, using :math:`|\psi\rangle` as initial state and
# measuring the expectation value of :math:`B`. This generator has the advantage that
# we can quickly create the cost function for various numbers of qubits — and therefore
# cost functions with different complexity.
#
# We will use the default qubit simulator with its JAX backend and also will rely
# on the NumPy implementation of JAX.
# To obtain precise results, we enable 64-bit ``float`` precision via the JAX config.

























###############################################################################
# We also prepare some plotting functionalities and colors:




# Set a plotting range on the x-axis


# Colors







###############################################################################
# Now that we took care of these preparations, let's dive right into it:
# It can be shown [#GenPar]_ that :math:`E(x)` takes the form of a
# Fourier series in the variable :math:`x`. That is to say that
#
# .. math ::
#
#   E(x) = a_0 + \sum_{\ell=1}^R a_{\ell}\cos(\ell x)+b_{\ell}\sin(\ell x).
#
# Here, :math:`a_{\ell}` and :math:`b_{\ell}` are the *Fourier coefficients*.
# If you would like to understand this a bit better still, have a read of
# :mod:`~.pennylane.fourier` and remember to check out the
# :doc:`Fourier module tutorial </demos/tutorial_expressivity_fourier_series>`.
#
# Due to :math:`B` being Hermitian, :math:`E(x)` is a real-valued function, so 
# only positive frequencies and real coefficients appear in the Fourier series for :math:`E(x)`.
# This is true for any number of qubits (and therefore ``RZ`` gates) we use.
#
# Using our function ``make_cost`` from above, we create the cost function for several
# numbers of qubits and store both the function and its evaluations on the plotting range ``X``.


# Qubit numbers

# Fix a seed











###############################################################################
# Let's take a look at the created :math:`E(x)` for the various numbers of qubits:


# Figure with multiple axes













###############################################################################
#
# |
#
# Indeed we see that :math:`E(x)` is a periodic function whose complexity grows when increasing
# :math:`N` together with the number of ``RZ`` gates.
# To take a look at the frequencies that are present in these functions, we may use
# PennyLane's :mod:`~.pennylane.fourier` module.
#
# .. note ::
#
#     The analysis tool :func:`~.pennylane.fourier.qnode_spectrum` makes use of the internal
#     structure of the :class:`~.pennylane.QNode` that encodes the cost function.
#     As we used the ``jax.jit`` decorator when defining the cost function above, we
#     here need to pass the wrapped function to ``qnode_spectrum``, which is stored in
#     ``cost_function.__wrapped__``.













###############################################################################
# The number of positive frequencies that appear in :math:`E(x)` is the same as the
# number of ``RZ`` gates we used in the circuit! Recall that we only need to consider
# the positive frequencies because :math:`E(x)` is real-valued, and that we accounted for
# the zero-frequency contribution in the coefficient :math:`a_0`.
# If you are interested why the number of gates coincides with the number of frequencies,
# check out the :doc:`Fourier module tutorial </demos/tutorial_expressivity_fourier_series>`.
#
# Before moving on, let's also have a look at the Fourier coefficients in the functions
# we created:





















###############################################################################
# We find the real (imaginary) Fourier coefficients to be (anti-)symmetric.
# This is expected because :math:`E(x)` is real-valued and we again see why it is enough
# to consider positive frequencies: the coefficients of the negative frequencies follow
# from those of the positive frequencies.
#
# Determining the full dependence on :math:`x`
# --------------------------------------------
#
# Next we will show how to determine the *full* dependence of the cost function on :math:`x`,
# i.e., we will *reconstruct* :math:`E(x)`.
# The key idea is not new: Since :math:`E(x)` is periodic with known, integer frequencies, we can
# reconstruct it *exactly* by using trigonometric interpolation.
# For this, we evaluate :math:`E` at shifted positions :math:`x_\mu`.
# We will show the reconstruction both for *equidistant* and random shifts, corresponding to a
# `uniform <https://en.wikipedia.org/wiki/Discrete_Fourier_transform>`_ and a
# `non-uniform <https://en.wikipedia.org/wiki/Non-uniform_discrete_Fourier_transform>`_
# discrete Fourier transform (DFT), respectively.
#
# Equidistant shifts
# ^^^^^^^^^^^^^^^^^^
#
# For the equidistant case we can directly implement the trigonometric interpolation:
#
# .. math ::
#
#   x_\mu &= \frac{2\mu\pi}{2R+1}\\
#   E(x) &=\sum_{\mu=-R}^R E\left(x_\mu\right) \frac{\sin\left(\frac{2R+1}{2}(x-x_\mu)\right)} {(2R+1)\sin \left(\frac{1}{2} (x-x_\mu)\right)},\\
#
# where we reformulated :math:`E` in the second expression using the
# `sinc function <https://en.wikipedia.org/wiki/Sinc_function>`__ to enhance the numerical 
# stability. Note that we have to take care of a rescaling factor of :math:`\pi` between 
# this definition of :math:`\operatorname{sinc}` and the NumPy implementation ``np.sinc``.
#
# .. note ::
#
#     When implementing :math:`E`, we will replace
#
#     .. math ::
#
#         \frac{\sin\left(\frac{2R+1}{2}(x-x_\mu)\right)} {(2R+1)\sin \left(\frac{1}{2} (x-x_\mu)\right)}
#
#     by 
#
#     .. math ::
#
#         \frac{\operatorname{sinc}\left(\frac{2R+1}{2}(x-x_\mu)\right)} {\operatorname{sinc} \left(\frac{1}{2} (x-x_\mu)\right)}
#
#     where the sinc function is defined as :math:`\operatorname{sinc}(x)=\sin(x)/x`. 
#     This enhances the numerical stability since :math:`\operatorname{sinc}(0)=1`, so that the
#     denominator does no longer vanish at the shifted points. 
#     Note that we have to take care of a rescaling factor of :math:`\pi`
#     between this definition of :math:`\operatorname{sinc}` and the NumPy implementation
#     ``np.sinc``.
























###############################################################################
# So how is this reconstruction doing? We will plot it along with the original function
# :math:`E`, mark the shifted evaluation points :math:`x_\mu` (with crosses), and also show
# its deviation from :math:`E(x)` (lower plots).
# For this, a function for the whole procedure of comparing the functions comes in handy, and
# we will reuse it further below. For convenience, showing the deviation will be an optional
# feature controled by the ``show_diff`` keyword argument.













































###############################################################################
# *It works!*
#
# Non-equidistant shifts
# ^^^^^^^^^^^^^^^^^^^^^^
#
# Now let's test the reconstruction with less regular sampling points on which to evaluate
# :math:`E`. This means we can no longer use the closed-form expression from above, but switch
# to solving the set of equations
#
# .. math ::
#
#   E(x_\mu) = a_0 + \sum_{\ell=1}^R a_{\ell}\cos(\ell x_\mu)+b_{\ell}\sin(\ell x_\mu)
#
# with the—now irregular—sampling points :math:`x_\mu`.
# For this, we set up the matrix
#
# .. math ::
#
#   C_{\mu\ell} = \begin{cases}
#   1 &\text{ if } \ell=0\\
#   \cos(\ell x_\mu) &\text{ if } 1\leq\ell\leq R\\
#   \sin(\ell x_\mu) &\text{ if } R<\ell\leq 2R,
#   \end{cases}
#
# collect the Fourier coefficients of :math:`E` into the vector
# :math:`\boldsymbol{W}=(a_0, \boldsymbol{a}, \boldsymbol{b})`, and the evaluations of :math:`E`
# into another vector called :math:`\boldsymbol{E}` so that
#
# .. math ::
#
#   \boldsymbol{E} = C \boldsymbol{W} \Rightarrow \boldsymbol{W} = C^{-1}\boldsymbol{E}.
#
# Let's implement this right away! We will take the function and the shifts :math:`x_\mu` as
# inputs, inferring :math:`R` from the number of the provided shifts, which is :math:`2R+1`.

































###############################################################################
# To see this version of the reconstruction in action, we will sample the
# shifts :math:`x_\mu` at random in :math:`[-\pi,\pi)`:








###############################################################################
# Again, we obtain a perfect reconstruction of :math:`E(x)` up to numerical errors.
# We see that the deviation from the original cost function became larger than for equidistant
# shifts for some of the qubit numbers but it still remains much smaller than any energy scale of
# relevance in applications.
# The reason for these larger deviations is that some evaluation positions :math:`x_\mu` were sampled
# very close to each other, so that inverting the matrix :math:`C` becomes less stable numerically.
# Conceptually, we see that the reconstruction does *not* rely on equidistant evaluations points.
#
# .. note ::
#
#     For some applications, the number of frequencies :math:`R` is not known exactly but an upper
#     bound for :math:`R` might be available. In this case, it is very useful that a reconstruction
#     that assumes *too many* frequencies in :math:`E(x)` works perfectly fine.
#     However, it has the disadvantage of spending too many evaluations on the reconstruction,
#     and the number of required measurements, which is meaningful for the (time)
#     complexity of quantum algorithms, does so as well!
#
# Differentiation via reconstructions
# -----------------------------------
#
# Next, we look at a modified reconstruction strategy that only obtains the odd or even part of
# :math:`E(x)`. This can be done by slightly modifying the shifted positions at which we
# evaluate :math:`E` and the kernel functions.
#
# From a perspective of implementing the derivatives there are two approaches, differing in 
# which parts we derive on paper and which we leave to the computer:
# In the first approach, we perform a partial reconstruction using the evaluations of the
# original cost function :math:`E` on the quantum computer, as detailed below.
# This gives us a function implemented in ``jax.numpy`` and we may afterwards apply 
# ``jax.grad`` to this function and obtain the derivative function. :math:`E(0)` then is only 
# one evaluation of this function away.
# In the second approach, we compute the derivative of the partial reconstructions *manually* and 
# directly implement the resulting shift rule that multiplies the quantum computer evaluations with
# coefficients and sums them up. This means that the partial reconstruction is not performed at
# all by the classical computer, but only was used on paper to derive the formula for the 
# derivative.
#
# *Why do we look at both approaches?*, you might ask. That is because neither of them is
# better than the other for *all* applications.
# The first approach offers us derivatives of any order without additional manual work by
# iteratively applying ``jax.grad``, which is very convenient. 
# However, the automatic differentiation via JAX becomes increasingly expensive
# with the order and we always reconstruct the *same* type of function, namely Fourier series,
# so that computing the respective derivatives once manually and coding up the resulting 
# coefficients of the parameter-shift rule pays off in the long run. This is the strength of the
# second approach.
# We start with the first approach.
#
# Automatically differentiated reconstructions
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#
# We implement the partial reconstruction method as a function; using PennyLane's
# automatic differentiation backends, this then enables us to obtain the derivatives at the point
# of interest. For odd-order derivatives, we use the reconstruction of the odd part, for the
# even-order derivatives that of the even part.
#
# We make use of modified `Dirichlet kernels <https://en.wikipedia.org/wiki/Dirichlet_kernel>`_
# :math:`\tilde{D}_\mu(x)` and equidistant shifts for this. For the odd reconstruction we have
#
# .. math ::
#
#   E_\text{odd}(x) &= \sum_{\mu=1}^R E_\text{odd}(x_\mu) \tilde{D}_\mu(x)\\
#   \tilde{D}_\mu(x) &= \frac{\sin(R (x-x_\mu))}{2R \tan\left(\frac{1}{2} (x-x_\mu)\right)} - \frac{\sin(R (x+x_\mu))}{2R \tan\left(\frac{1}{2} (x+x_\mu)\right)},
#
# which we can implement using the reformulation
#
# .. math ::
#
#   \frac{\sin(X)}{\tan(Y)}=\frac{X}{Y}\frac{\operatorname{sinc}(X)}{\operatorname{sinc}(Y)}\cos(Y)
#
# for the kernel.



# Odd linear combination of Dirichlet kernels


























###############################################################################
# The even part on the other hand takes the form
#
# .. math ::
#
#   E_\text{even}(x) &= \sum_{\mu=0}^R E_\text{even}(x_\mu) \hat{D}_\mu(x)\\
#   \hat{D}_\mu(x) &=
#   \begin{cases}
#      \frac{\sin(Rx)}{2R \tan(x/2)} &\text{if } \mu = 0 \\[12pt]
#      \frac{\sin(R (x-x_\mu))}{2R \tan\left(\frac{1}{2} (x-x_\mu)\right)} + \frac{\sin(R (x+x_\mu))}{2R \tan\left(\frac{1}{2} (x+x_\mu)\right)} & \text{if } \mu \in [R-1] \\[12pt]
#      \frac{\sin(R (x-\pi))}{2R \tan\left(\frac{1}{2} (x-\pi)\right)} & \text{if } \mu = R.
#   \end{cases}
#
# Note that not only the kernels :math:`\hat{D}_\mu(x)` but also the shifted positions
# :math:`\{x_\mu\}` differ between the odd and even case.



# Even linear combination of Dirichlet kernels









# Special cases of even kernels





















###############################################################################
# We also set up a function that performs both partial reconstructions and sums the resulting
# functions to the full Fourier series.

















###############################################################################
# We show these even (blue) and odd (red) reconstructions and how they indeed
# sum to the full function (orange, dashed).
# We will again use the ``compare_functions`` utility from above for the comparison.



# Obtain the shifts for the reconstruction of both parts











# Show the reconstructed parts and the sums


















###############################################################################
# Great! The even and odd part indeed sum to the correct function again. But what did we
# gain? 
#
# Nothing, actually, for the full reconstruction! Quite the opposite, we spent :math:`2R`
# evaluations of :math:`E` on each part, that is :math:`4R` evaluations overall to obtain a
# description of the full function :math:`E`! This is way more than the :math:`2R+1`
# evaluations needed for the full reconstructions from the beginning.
#
# However, remember that we set out to compute derivatives of :math:`E` at :math:`0`, so that
# for derivatives of odd/even order only the odd/even reconstruction is required.
# Using an autodifferentiation framework, e.g. JAX, we can easily compute such higher-order
# derivatives:


# An iterative function computing the ``order``th derivative of a function ``f`` with JAX


# Compute the first, second, and fourth derivative













###############################################################################
# The derivatives coincide.
#
# .. note ::
#
#     While we used the :math:`2R+1` evaluations :math:`x_\mu=\frac{2\mu\pi}{2R+1}` for the full
#     reconstruction, derivatives only require :math:`2R` calls to the respective circuit.
#     Also note that the derivatives can be computed at any position :math:`x_0` other than
#     :math:`0` by simply reconstructing the function :math:`E(x+x_0)`, which again will be
#     a Fourier series like :math:`E(x)`.
#
# Generalized parameter-shift rules
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# The second method is based on the previous one. Instead of consulting JAX, we may compute
# the wanted derivative of the odd/even kernel function manually and thus derive general
# parameter-shift rules from this. We will leave the technical derivation of these rules
# to the paper [#GenPar]_. Start with the first derivative, which certainly is used the most:
#
# .. math ::
#
#   E'(0) = \sum_{\mu=1}^{2R} E\left(\frac{2\mu-1}{2R}\pi\right) \frac{(-1)^{\mu-1}}{4R\sin^2\left(\frac{2\mu-1}{4R}\pi\right)},
#
# This is straight-forward to implement by defining the coefficients and evaluating
# :math:`E` at the shifted positions :math:`x_\mu`:

















###############################################################################
# The second-order derivative takes a similar form, but we have to take care of the evaluation at
# :math:`0` and the corresponding coefficient separately:
#
# .. math ::
#
#   E''(0) = -E(0)\frac{2R^2+1}{6} - \sum_{\mu=1}^{2R-1} E\left(\frac{\mu\pi}{R}\right)\frac{(-1)^\mu}{2\sin^2 \left(\frac{\mu\pi}{2R}\right)}.
#
# Let's code this up, again we only get slight complications from the special evaluation
# at :math:`0`:



















###############################################################################
# We will compare these two shift rules to the finite-difference derivative commonly used for
# numerical differentiation. We choose a finite difference of :math:`d_x=5\times 10^{-5}`.
















###############################################################################
# All that is left is to compare the computed parameter-shift and finite-difference
# derivatives:







###############################################################################
# The parameter-shift rules work as expected! And we were able to save
# a circuit evaluation as compared to a full reconstruction.
#
# And this is all we want to show here about univariate function reconstructions and generalized
# parameter shift rules.
# Note that the techniques above can partially be extended to frequencies that are not
# integer-valued, but many closed form expressions are no longer valid.
# For the reconstruction, the approach via Dirichlet kernels no longer works in the general
# case; instead, a system of equations has to be solved, but with generalized
# frequencies :math:`\{\Omega_\ell\}` instead of :math:`\{\ell\}` (see e.g. 
# Sections III A-C in [#GenPar]_)
#
#
# References
# ----------
#
# .. [#GenPar]
#
#     David Wierichs, Josh Izaac, Cody Wang, Cedric Yen-Yu Lin.
#     "General parameter-shift rules for quantum gradients".
#     `arXiv preprint arXiv:2107.12390 <https://arxiv.org/abs/2107.12390>`__.
#
# .. [#CalcPQC]
#
#     Javier Gil Vidal, Dirk Oliver Theis. "Calculus on parameterized quantum circuits".
#     `arXiv preprint arXiv:1812.06323 <https://arxiv.org/abs/1812.06323>`__.
#
# .. [#Rotosolve]
#
#     Mateusz Ostaszewski, Edward Grant, Marcello Benedetti.
#     "Structure optimization for parameterized quantum circuits".
#     `arXiv preprint arXiv:1905.09692 <https://arxiv.org/abs/1905.09692>`__.
#
# .. [#AlgeShift]
#
#     Artur F. Izmaylov, Robert A. Lang, Tzu-Ching Yen.
#     "Analytic gradients in variational quantum algorithms: Algebraic extensions of the parameter-shift rule to general unitary transformations".
#     `arXiv preprint arXiv:2107.08131 <https://arxiv.org/abs/2107.08131>`__.
#
# .. [#GenDiffRules]
#
#     Oleksandr Kyriienko, Vincent E. Elfving.
#     "Generalized quantum circuit differentiation rules".
#     `arXiv preprint arXiv:2108.01218 <https://arxiv.org/abs/2108.01218>`__.
#
# .. |brute| replace:: ``brute``
# .. _brute: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.brute.html
#
# .. |shgo| replace:: ``shgo``
# .. _shgo: https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.shgo.html
#
# .. |Rotosolve_code| replace:: ``qml.RotosolveOptimizer``
# .. _Rotosolve_code: https://pennylane.readthedocs.io/en/stable/code/api/pennylane.RotosolveOptimizer.html

##############################################################################
# About the author
# ----------------
# .. include:: ../_static/authors/david_wierichs.txt
