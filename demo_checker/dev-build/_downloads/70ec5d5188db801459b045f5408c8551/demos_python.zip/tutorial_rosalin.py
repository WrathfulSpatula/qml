r"""
Frugal shot optimization with Rosalin
=====================================

.. meta::
    :property="og:description": The Rosalin optimizer uses a measurement-frugal optimization strategy to minimize the
         number of times a quantum computer is accessed.
    :property="og:image": https://pennylane.ai/qml/_images/sphx_glr_tutorial_rosalin_002.png

.. related::

   tutorial_vqe A brief overview of VQE
   tutorial_quantum_natural_gradient Quantum natural gradient
   tutorial_doubly_stochastic Doubly stochastic gradient descent
   tutorial_rotoselect Quantum circuit structure learning

*Author: Josh Izaac — Posted: 19 May 2020. Last updated: 30 January 2023.*

In this tutorial we investigate and implement the Rosalin (Random Operator Sampling for
Adaptive Learning with Individual Number of shots) from
Arrasmith et al. [#arrasmith2020]_. In this paper, a strategy
is introduced for reducing the number of shots required when optimizing variational quantum
algorithms, by both:

* Frugally adapting the number of shots used per parameter update, and
* Performing a weighted sampling of operators from the cost Hamiltonian.

.. note::

    The Rosalin optimizer is available in PennyLane via the
    :class:`~.pennylane.ShotAdaptiveOptimizer`.

Background
----------

While a large number of papers in variational quantum algorithms focus on the
choice of circuit ansatz, cost function, gradient computation, or initialization method,
the optimization strategy—an important component affecting both convergence time and
quantum resource dependence—is not as frequently considered. Instead, common
'out-of-the-box' classical optimization techniques, such as gradient-free
methods (COBLYA, Nelder-Mead), gradient-descent, and Hessian-free methods (L-BFGS) tend to be used.

However, for variational algorithms such as :doc:`VQE </demos/tutorial_vqe>`, which involve evaluating
a large number of non-commuting operators in the cost function, decreasing the number of
quantum evaluations required for convergence, while still minimizing statistical noise, can
be a delicate balance.

Recent work has highlighted that 'quantum-aware' optimization techniques
can lead to marked improvements when training variational quantum algorithms:

* :doc:`/demos/tutorial_quantum_natural_gradient` descent by Stokes et al. [#stokes2019]_, which
  takes into account the quantum geometry during the gradient-descent update step.

* The work of Sweke et al. [#sweke2019]_, which shows
  that quantum gradient descent with a finite number of shots is equivalent to
  `stochastic gradient descent <https://en.wikipedia.org/wiki/Stochastic_gradient_descent>`_,
  and has guaranteed convergence. Furthermore, combining a finite number of shots with
  weighted sampling of the cost function terms leads to :doc:`/demos/tutorial_doubly_stochastic`.

* The iCANS (individual Coupled Adaptive Number of Shots) optimization technique by
  Jonas Kuebler et al. [#kubler2020]_ adapts the number
  of shots measurements during training, by maximizing the expected gain per shot.

In this latest result by Arrasmith et al. [#arrasmith2020]_, the
idea of doubly stochastic gradient descent has been used to extend the iCANS optimizer,
resulting in faster convergence.

Over the course of this tutorial, we will explore their results; beginning first with a
demonstration of *weighted random sampling* of the cost Hamiltonian operators, before
combining this with the shot-frugal iCANS optimizer to perform doubly stochastic
Rosalin optimization.

Weighted random sampling
------------------------

Consider a Hamiltonian :math:`H` expanded as a weighted sum of operators :math:`h_i` that can
be directly measured:

.. math:: H = \sum_{i=1}^N c_i h_i.

Due to the linearity of expectation values, the expectation value of this Hamiltonian
can be expressed as the weighted sum of each individual term:

.. math:: \langle H\rangle = \sum_{i=1}^N c_i \langle h_i\rangle.

In the :doc:`doubly stochastic gradient descent demonstration </demos/tutorial_doubly_stochastic>`,
we estimated this expectation value by **uniformly sampling** a subset of the terms
at each optimization step, and evaluating each term by using the same finite number of shots
:math:`N`.

However, what happens if we use a weighted approach to determine how to distribute
our samples across the terms of the Hamiltonian? In **weighted random sampling** (WRS),
the number of shots used to determine the expectation value :math:`\langle h_i\rangle`
is a discrete random variable distributed according to a
`multinomial distribution <https://en.wikipedia.org/wiki/Multinomial_distribution>`__,

.. math:: S \sim \text{Multinomial}(p_i),

with event probabilities

.. math:: p_i = \frac{|c_i|}{\sum_i |c_i|}.

That is, the number of shots assigned to the measurement of the expectation value of the
:math:`i\text{th}` term of the Hamiltonian is drawn from a probability distribution
*proportional to the magnitude of its coefficient* :math:`c_i`.

To see this strategy in action, consider the Hamiltonian

.. math:: H = 2I\otimes X + 4 I\otimes Z  - X\otimes X + 5Y\otimes Y + 2 Z\otimes X.

We can solve for the ground state energy using the variational quantum eigensolver (VQE) algorithm.

First, let's import NumPy and PennyLane, and define our Hamiltonian.
"""



# set the random seed













##############################################################################
# We can now create our quantum device (let's use the ``default.qubit`` simulator).




# create a device that estimates expectation values using a finite number of shots


# create a device that calculates exact expectation values


##############################################################################
# Now, let's set the total number of shots, and determine the probability
# for sampling each Hamiltonian term.





##############################################################################
# We can now use SciPy to create our multinomial distributed random variable
# :math:`S`, using the number of trials (total shot number) and probability values:





##############################################################################
# Sampling from this distribution will provide the number of shots used to
# sample each term in the Hamiltonian:





##############################################################################
# As expected, if we sum the sampled shots per term, we recover the total number of shots.
#
# Let's now create our cost function. Recall that the cost function must do the
# following:
#
# 1. It must sample from the multinomial distribution we created above,
#    to determine the number of shots :math:`s_i` to use to estimate the expectation
#    value of the ith Hamiltonian term.
#
# 2. It then must estimate the expectation value :math:`\langle h_i\rangle`
#    by creating the required QNode. For our ansatz, we'll use the 
#    :class:`~.pennylane.templates.layers.StronglyEntanglingLayers`.
#
# 3. And, last but not least, estimate the expectation value
#    :math:`\langle H\rangle = \sum_i c_i\langle h_i\rangle`.
#























##############################################################################
# Evaluating our cost function with some initial parameters, we can test out
# that our cost function evaluates correctly.






##############################################################################
# Performing the optimization, with the number of shots randomly
# determined at each optimization step:













##############################################################################
# Let's compare this against an optimization not using weighted random sampling.
# Here, we will split the 8000 total shots evenly across all Hamiltonian terms,
# also known as *uniform deterministic sampling*.































##############################################################################
# Comparing these two techniques:












##############################################################################
# We can see that weighted random sampling performs just as well as the uniform
# deterministic sampling. However, weighted random sampling begins to show a
# non-negligible improvement over deterministic sampling for large Hamiltonians
# with highly non-uniform coefficients. For example, see Fig (3) and (4) of
# Arrasmith et al. [#arrasmith2020]_, comparing weighted random sampling VQE optimization
# for both :math:`\text{H}_2` and :math:`\text{LiH}` molecules.
#
# .. note::
#
#     While not covered here, another approach that could be taken is
#     *weighted deterministic sampling*. Here, the number of shots is distributed
#     across terms as per
#
#     .. math:: s_i = \left\lfloor N \frac{|c_i|}{\sum_i |c_i|}\right\rfloor,
#
#     where :math:`N` is the total number of shots.
#

##############################################################################
# Rosalin: Frugal shot optimization
# ---------------------------------
#
# We can see above that both methods optimize fairly well; weighted random
# sampling converges just as well as evenly distributing the shots across
# all Hamiltonian terms. However, deterministic shot distribution approaches
# will always have a minimum shot value required per expectation value, as below
# this threshold they become biased estimators. This is not the case with random
# sampling; as we saw in the
# :doc:`doubly stochastic gradient descent demonstration </demos/tutorial_doubly_stochastic>`,
# the introduction of randomness allows for as little
# as a single shot per expectation term, while still remaining an unbiased estimator.
#
# Using this insight, Arrasmith et al. [#arrasmith2020]_ modified the iCANS frugal
# shot-optimization technique [#kubler2020]_ to include weighted random sampling, making it
# 'doubly stochastic'.
#
# iCANS optimizer
# ~~~~~~~~~~~~~~~
#
# Two variants of the iCANS optimizer were introduced in Kübler et al., iCANS1 and iCANS2.
# The iCANS1 optimizer, on which Rosalin is based, frugally distributes a shot budget
# across the partial derivatives of each parameter, which are computed using the
# :doc:`parameter-shift rule </glossary/quantum_gradient>`. It works roughly as follows:
#
# 1. The initial step of the optimizer is performed with some specified minimum
#    number of shots, :math:`s_{min}`, for all partial derivatives.
#
# 2. The parameter-shift rule is then used to estimate the gradient :math:`g_i`
#    for each parameter :math:`\theta_i`, parameters, as well as the *variances*
#    :math:`v_i` of the estimated gradients.
#
# 3. Gradient descent is performed for each parameter :math:`\theta_i`, using
#    the pre-defined learning rate :math:`\alpha` and the gradient information :math:`g_i`:
#
#    .. math:: \theta_i = \theta_i - \alpha g_i.
#
# 4. The improvement in the cost function per shot, for a specific parameter value,
#    is then calculated via
#
#    .. math::
#
#        \gamma_i = \frac{1}{s_i} \left[ \left(\alpha - \frac{1}{2} L\alpha^2\right)
#                    g_i^2 - \frac{L\alpha^2}{2s_i}v_i \right],
#
#    where:
#
#    * :math:`L \leq \sum_i|c_i|` is the bound on the `Lipschitz constant
#      <https://en.wikipedia.org/wiki/Lipschitz_continuity>`__ of the variational quantum algorithm objective function,
#
#    * :math:`c_i` are the coefficients of the Hamiltonian, and
#
#    * :math:`\alpha` is the learning rate, and *must* be bound such that :math:`\alpha < 2/L`
#      for the above expression to hold.
#
# 5. Finally, the new values of :math:`s_i` (shots for partial derivative of parameter
#    :math:`\theta_i`) is given by:
#
#    .. math::
#
#        s_i = \frac{2L\alpha}{2-L\alpha}\left(\frac{v_i}{g_i^2}\right)\propto
#              \frac{v_i}{g_i^2}.
#
# In addition to the above, to counteract the presence of noise in the system, a
# running average of :math:`g_i` and :math:`s_i` (:math:`\chi_i` and :math:`\xi_i` respectively)
# are used when computing :math:`\gamma_i` and :math:`s_i`.
#
# .. note::
#
#     In classical machine learning, the Lipschitz constant of the cost function is generally
#     unknown. However, for a variational quantum algorithm with cost of the form
#     :math:`f(x) = \langle \psi(x) | \hat{H} |\psi(x)\rangle`,
#     an upper bound on the Lipschitz constant is given by :math:`L < \sum_i|c_i|`,
#     where :math:`c_i` are the coefficients of :math:`\hat{H}` when decomposed
#     into a linear combination of Pauli-operator tensor products.
#
# Rosalin implementation
# ~~~~~~~~~~~~~~~~~~~~~~
#
# Let's now modify iCANS above to incorporate weighted random sampling of Hamiltonian
# terms — the Rosalin frugal shot optimizer.
#
# Rosalin takes several hyper-parameters:
#
# * ``min_shots``: the minimum number of shots used to estimate the expectations
#   of each term in the Hamiltonian. Note that this must be larger than 2 for the variance
#   of the gradients to be computed.
#
# * ``mu``: The running average constant :math:`\mu\in[0, 1]`. Used to control how quickly the
#   number of shots recommended for each gradient component changes.
#
# * ``b``: Regularization bias. The bias should be kept small, but non-zero.
#
# * ``lr``: The learning rate. Recall from above that the learning rate *must* be such
#   that :math:`\alpha < 2/L = 2/\sum_i|c_i|`.
#
# Since the Rosalin optimizer has a state that must be preserved between optimization steps,
# let's use a class to create our optimizer.
#





















































































































































##############################################################################
# Rosalin optimization
# ~~~~~~~~~~~~~~~~~~~~
#
# We are now ready to use our Rosalin optimizer to optimize the initial VQE problem. But first let's
# also create a separate cost function using an 'exact' quantum device, so that we can keep track of the
# *exact* cost function value at each iteration.






##############################################################################
# Creating the optimizer and beginning the optimization:















##############################################################################
# Let's compare this to a standard Adam optimization. Using 100 shots per quantum
# evaluation, for each update step there are 2 quantum evaluations per parameter.





##############################################################################
# Thus, Adam is using 2400 shots per update step.




















##############################################################################
# Plotting both experiments:











##############################################################################
# The Rosalin optimizer performs significantly better than the Adam optimizer,
# approaching the ground state energy of the Hamiltonian with strikingly
# fewer shots.
#
# While beyond the scope of this demonstration, the Rosalin optimizer can be
# modified in various other ways; for instance, by incorporating *weighted hybrid
# sampling* (which distributes some shots deterministically, with the remainder
# done randomly), or by adapting the variant iCANS2 optimizer. Download
# this demonstration from the sidebar 👉 and give it a go! ⚛️


##############################################################################
# References
# ----------
#
# .. [#arrasmith2020]
#
#     Andrew Arrasmith, Lukasz Cincio, Rolando D. Somma, and Patrick J. Coles. "Operator Sampling
#     for Shot-frugal Optimization in Variational Algorithms." `arXiv:2004.06252
#     <https://arxiv.org/abs/2004.06252>`__ (2020).
#
# .. [#stokes2019]
#
#     James Stokes, Josh Izaac, Nathan Killoran, and Giuseppe Carleo. "Quantum Natural Gradient."
#     `arXiv:1909.02108 <https://arxiv.org/abs/1909.02108>`__ (2019).
#
# .. [#sweke2019]
#
#     Ryan Sweke, Frederik Wilde, Johannes Jakob Meyer, Maria Schuld, Paul K. Fährmann, Barthélémy
#     Meynard-Piganeau, and Jens Eisert. "Stochastic gradient descent for hybrid quantum-classical
#     optimization." `arXiv:1910.01155 <https://arxiv.org/abs/1910.01155>`__ (2019).
#
# .. [#kubler2020]
#
#     Jonas M. Kübler, Andrew Arrasmith, Lukasz Cincio, and Patrick J. Coles. "An Adaptive Optimizer
#     for Measurement-Frugal Variational Algorithms." `Quantum 4, 263
#     <https://quantum-journal.org/papers/q-2020-05-11-263/>`__ (2020).
#
#
# About the author
# ----------------
# .. include:: ../_static/authors/josh_izaac.txt