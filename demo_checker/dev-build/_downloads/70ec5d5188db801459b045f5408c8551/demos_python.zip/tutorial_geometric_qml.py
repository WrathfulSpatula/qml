r"""

Introduction to Geometric Quantum Machine Learning
==================================================

.. meta::
    :property="og:description": Using the natural symmetries in a quantum learning problem can improve learning
    :property="og:image": https://pennylane.ai/qml/_images/equivariant_thumbnail.jpeg

.. related::
   tutorial_equivariant_graph_embedding A permutation equivariant graph embedding
   
*Author: Richard East — Posted: 18 October 2022.*


Introduction
------------


Symmetries are at the heart of physics. Indeed in condensed matter and
particle physics we often define a thing simply by the symmetries it
adheres to. What does symmetry mean for those in machine learning? In
this context the ambition is straightforward — it is a means to
reduce the parameter space and improve the trained model's ability to
sucessfully label unseen data, i.e., its ability to generalise.


Suppose we have a learning task and the data we are learning from has an
underlying symmetry. For example, consider a game of Noughts and
Crosses (aka Tic-tac-toe): if we win a game, we would have won it if the board was rotated
or flipped along any of the lines of symmetry. Now if we want to train
an algorithm to spot the outcome of these games, we can either ignore
the existence of this symmetry or we can somehow include it. The
advantage of paying attention to the symmetry is it identifies multiple
configurations of the board as 'the same thing' as far as the symmetry
is concerned. This means we can reduce our parameter space, and so the
amount of data our algorithm must sift through is immediately reduced.
Along the way, the fact that our learning model must encode a symmetry
that actually exists in the system we are trying to represent naturally
encourages our results to be more generalisable. The encoding of symmetries
into our learning models is where the term *equivariance* will appear. We will see that
demanding that certain symmetries are included in our models means that the 
mappings that make up our algorithms must be such that we could transform our input data
with respect to a certain symmetry, then apply our mappings, and this would be the same as applying
the mappings and then transforming the output data with the same symmetry. This is the technical property
that gives us the name "equavariant learning".

In classical machine learning, this area is often referred to as geometric deep
learning (GDL) due to the traditional association of symmetry to the
world of geometry, and the fact that these considerations usually focus on
deep neural networks (see [#Bronstein2021]_ or [#Nguyen2022]_ for a broad introduction).
We will refer to the quantum computing version of this as *quantum geometric machine learning* (QGML).


Representation theory in circuits
---------------------------------

The first thing to discuss is how do we work with symmetries in the
first place? The answer lies in the world of group representation
theory.

First, let's define what we mean by a group:

**Definition**: A group is a set :math:`G` together with a binary operation
on :math:`G`, here denoted :math:`\circ`, that combines any two elements
:math:`a` and :math:`b` to form an element of :math:`G`, denoted
:math:`a \circ b`, such that the following three requirements, known as
group axioms, are satisfied as follows:


1. **Associativity**: For all :math:`a, b, c` in :math:`G`, one has :math:`(a \circ b) \circ c=a \circ (b \circ c)`.

2. **Identity element**: There exists an element :math:`e` in :math:`G` such that, for every :math:`a` in :math:`G`, one 
    has :math:`e \circ a=a` and :math:`a \circ e=a`. Such an element is unique. It is called the identity element of the
    group.


3. **Inverse element**: For each :math:`a` in :math:`G`, there exists an element :math:`b` in :math:`G`
    such that :math:`a \circ b=e` and :math:`b \circ a=e`, where :math:`e` is the identity element.
    For each :math:`a`, the element :math:`b` is unique:  it is called the inverse of :math:`a` 
    and is commonly denoted :math:`a^{-1}`.


With groups defined, we are in a position to articulate what a
representation is: Let :math:`\varphi` be a map sending :math:`g` in group
:math:`G` to a linear map :math:`\varphi(g): V \rightarrow V`, for some
vector space :math:`V`, which satisfies

.. math::
    \varphi\left(g_{1} g_{2}\right)=\varphi\left(g_{1}\right) \circ \varphi\left(g_{2}\right) \quad \text { for all } g_{1}, g_{2} \in G.

The idea here is that just as elements in a group act on each other to 
reach further elements, i.e., :math:`g\circ h = k`, a representation sends us 
to a mapping acting on a vector space such that :math:`\varphi(g)\circ \varphi(h) = \varphi(k)`.
In this way we are representing the structure of the group as a linear map. For a representation, our mapping must send us to the general linear
group :math:`GL(n)` (the space of invertible :math:`n \times n` matrices with matrix multiplication as the group multiplication). Note how this
is both a group, and by virtue of being a collection of invertible matrices, also a set of linear maps (they're all invertble matrices that can act on row vectors). 
Fundamentally, representation theory is based on the prosaic observation that linear algebra is easy and group theory is abstract. So what if we can
study groups via linear maps?

Now due to the importance of unitarity in quantum mechnics, we are
particularly interested in the unitary representations: representations
where the linear maps are unitary matrices. If we can
identify these then we will have a way to naturally encode groups in 
quantum circuits (which are mostly made up of unitary gates). 

.. figure:: ../demonstrations/geometric_qml/sphere_equivariant.png
    :align: center
    :width: 45%
    :alt: Basic symmetries of the sphere.

How does all this relate to symmetries? Well, a large class of
symmetries can be characterised as a group, where all the elements of the group leave 
some space we are considering unchanged. Let's consider an example:
the symmetries of a sphere. Now when we think of this symmetry we
probably think something along the lines of "it's the same no matter how
we rotate it, or flip it left to right, etc". There is this idea of being
invariant under some operation. We also have the idea of being able to
undo these actions: if we rotate one way, we can rotate it back. If we
flip the sphere right-to-left we can flip it left-to-right to get back to
where we started (notice too all these inverses are unique). Trivially
we can also do nothing. What exactly are we describing here? We have
elements that correspond to an action on a sphere that can be inverted and
for which there exists an identity. It is also trivially the case here
that if we consider three operations a, b, c from the set of rotations and
reflections of the sphere, that if we combine two of them together then
:math:`a\circ (b \circ c) = (a\circ b) \circ c`. The operations are
associative. These features turn out to literally define a group!
 
As we've seen the group in itself is a very abstract creature; this is why we look to
its representations. The group labels what symmetries we care about, they tell
us the mappings that our system is invariant under, and the unitary representations 
show us how those symmetries look on a particular
space of unitary matrices. If we want to
encode the structure of the symmeteries in a quantum circuit we must
restrict our gates to being unitary representations of the group.

There remains one question: *what is equivariance?* With our newfound knowledge
of group representation theory we are ready to tackle this. Let :math:`G` be our group, and
:math:`V` and :math:`W`, with elements :math:`v` and :math:`w` respectively, be vector spaces
over some field :math:`F` with a map :math:`f` between them.
Suppose we have representations :math:`\varphi: G \rightarrow GL(V)` 
and :math:`\psi: G \rightarrow GL(W)`. Furthermore, let's write
:math:`\varphi_g` for the representation of :math:`g` as a linear map on :math:`V` and :math:`\psi_g` 
as the same group element represented as a linear map on :math:`W` respectively. We call :math:`f` *equivariant* if

.. math::

    f(\varphi_g(v))=\psi_g(f(v)) \quad \text { for all } g\in G.

The importance of such a map in machine learning is that if, for example, our neural network layers are
equivariant maps then two inputs that are related by some intrinsic symmetry (maybe they are reflections)
preserve this information in the outputs.

Consider the following figure for 
example. What we see is a board with a cross in a certain square on the left and some numerical encoding of this
on the right, where the 1 is where the X is in the number grid. We present an equivariant mapping between these two spaces
with respect to a group action that is a rotation or a swap (here a :math:`\pi` rotation). We can either apply a group action to the original grid
and then map to the number grid, or we could map to the number grid and then apply the group action.
Equivariance demands that the result of either of these procedures should be the same.


.. figure:: ../demonstrations/geometric_qml/equivariant-example.jpg
    :align: center
    :width: 80%
    :alt: The commuting square of an equivariant map.



Given the vast amount
of input data required to train a neural network the principle that one can pre-encode known symmetry structures
into the network allows us to learn better and faster. Indeed it is the reason for the success of convolutional neural networks (CNNs) for image
analysis, where it is known they are equivariant with respect to translations. They naturally encode the idea that
a picture of a dog is symmetrically related to the same picture slid to the left by n pixels, and they do this by having 
neural network layers that are equivariant maps. With our focus on
unitary representations (and so quantum circuits) we are looking to extend this idea to quantum machine learning.

"""


##############################################################################
#
# Noughts and Crosses
# -------------------
# Let's look at the game of noughts and crosses, as inspired by [#Meyer2022]_. Two players take
# turns to place a O or an X, depending on which player they are, in a 3x3
# grid. The aim is to get three of your symbols in a row, column, or
# diagonal. As this is not always possible depending
# on the choices of the players, there could be a draw. Our learning task
# is to take a set of completed games labelled with their outcomes and
# teach the algorithm to identify these correctly.
#


######################################################################
# This board of nine elements has the symmetry of the square, also known
# as the *dihedral group*. This means it is symmetric under
# :math:`\frac{\pi}{2}` rotations and flips about the lines of symmetry of
# a square (vertical, horizontal, and both diagonals).

##############################################################################
# .. figure:: ../demonstrations/geometric_qml/NandC_sym.png
#     :align: center
#     :width: 70%
#     :alt: Examples of games that are equivalent under relevant symmetries.

##############################################################################
# **The question is, how do we encode this in our QML problem?**
#
# First, let us encode this problem classically. We will consider a nine-element
# vector :math:`v`, each element of which identifies a square of
# the board. The entries themselves can be
# :math:`+1`,\ :math:`0`,\ :math:`-1,` representing a nought, no symbol, or
# a cross. The label is one-hot encoded in a vector
# :math:`y=(y_O,y_- , y_X)` with :math:`+1` in the correct label and
# :math:`-1` in the others. For instance (-1,-1,1) would represent an X in
# the relevant position.


######################################################################
# To create the quantum model let us take nine qubits and let them represent squares of our board. We'll initialise them all as :math:`|0\rangle`,
# which we note leaves the board invariant under the symmetries of the problem (flip and
# rotate all you want, it's still going to be zeroes whatever your
# mapping). We will then look to apply single qubit :math:`R_x(\theta)`
# rotations on individual qubits, encoding each of the
# possibilities in the board squares at an angle of
# :math:`\frac{2\pi}{3}` from each other. For our parameterised gates we
# will have a single-qubit :math:`R_x(\theta_1)` and :math:`R_y(\theta_2)`
# rotation at each point. We will then use :math:`CR_y(\theta_3)` for two-qubit
# entangling gates. This implies that, for each encoding, crudely, we'll
# need 18 single-qubit rotation parameters and :math:`\binom{9}{2}=36` 
# two-qubit gate rotations. Let's see how, by using symmetries, we can reduce
# this.

##############################################################################
# .. figure:: ../demonstrations/geometric_qml/grid.jpg
#     :align: center
#     :width: 35%
#     :alt: The indexing of our game board.
#
#     ..
#
#     The indexing of our game board.

######################################################################
# The secret will be to encode the symmetries into the gate set so the
# observables we are interested in inherently respect the symmetries. How do
# we do this? We need to select the collections of gates that commute with
# the symmetries. In general, we can use the twirling formula for this:
#
# .. tip::
#
#    Let :math:`\mathcal{S}` be the group that encodes our symmetries and :math:`U` be a
#    unitary representation of :math:`\mathcal{S}`. Then,
#
#    .. math:: \mathcal{T}_{U}[X]=\frac{1}{|\mathcal{S}|} \sum_{s \in \mathcal{S}} U(s) X U(s)^{\dagger}
#
#    defines a projector onto the set of operators commuting with all
#    elements of the representation, i.e.,
#    :math:`\left[\mathcal{T}_{U}[X], U(s)\right]=` 0 for all :math:`X` and
#    :math:`s \in \mathcal{S}`.
#
# The twirling process applied to an arbitrary unitary will give us a new unitary that commutes with the group as we require.
# We remember that unitary gates typically have the form :math:`W = \exp(-i\theta H)`, where :math:`H` is a Hermitian 
# matrix called a *generator*, and :math:`\theta` may be fixed or left as a free parameter. A recipe for creating a unitary 
# that commutes with our symmetries is to *twirl the generator of the gate*, i.e., we move from the gate 
# :math:`W = \exp(-i\theta H)` to the gate :math:`W' = \exp(-i\theta\mathcal{T}_U[H])`. 
# When each term in the twirling formula acts on different qubits, then this unitary 
# would further simplify to 
#
# .. math:: W' = \bigotimes_{s\in\mathcal{S}}U(s)\exp(-i\tfrac{\theta}{\vert\mathcal{S}\vert})U(s)^\dagger.
#
# For simplicity, we can absorb the normalization factor :math:`\vert\mathcal{S}\vert` into the free parameter :math:`\theta`.
#
# So let's look again at our choice of gates: single-qubit
# :math:`R_x(\theta)` and :math:`R_y(\theta)` rotations, and entangling two-qubit :math:`CR_y(\phi)`
# gates. What will we get by twirling these?
#


######################################################################
# In this particular instance we can see the action of the twirling
# operation geometrically as the symmetries involved are all
# permutations. Let's consider the :math:`R_x` rotation acting on one qubit. Now
# if this qubit is in the centre location on the grid, then we can flip around any symmetry axis we
# like, and this operation leaves the qubit invariant, so we've identified one equivariant
# gate immediately. If the qubit is on the corners, then the flipping will send
# this qubit rotation to each of the other corners. Similarly, if a qubit is on the central
# edge then the rotation gate will be sent round the other edges. So we can see that the
# twirling operation is a sum over all the possible outcomes of performing
# the symmetry action (the sum over the symmetry group actions). Having done this
# we can see that for a single-qubit rotation the invariant maps are rotations
# on the central qubit, at all the corners, and at all the central
# edges (when their rotation angles are fixed to be the same). 
#
# As an example consider the following figure, 
# where we take a :math:`R_x` gate in the corner and then apply all the symmetries
# of a square. The result of this twirling leads us to have the same gate at all the corners.

##############################################################################
# .. figure:: ../demonstrations/geometric_qml/twirl.jpeg
#     :align: center
#     :width: 70%
#     :alt: The effect of twirling a rotation gate applied in one corner with the symmetries of a square.


######################################################################
# For entangling gates the situation is similar. There are three invariant
# classes, the centre entangled with all corners, with all edges, and the
# edges paired in a ring.
#


######################################################################
# The prediction of a label is obtained via a one-hot-encoding by measuring
# the expectation values of three invariant observables:
#


######################################################################
# .. math::
#   O_{-}=Z_{\text {middle }}=Z_{4}
#
# .. math::
#   O_{\circ}=\frac{1}{4} \sum_{i \in \text { corners }} Z_{i}=\frac{1}{4}\left[Z_{0}+Z_{2}+Z_{6}+Z_{8}\right]
#
# .. math::
#   O_{\times}=\frac{1}{4} \sum_{i \in \text { edges }} Z_{i}=\frac{1}{4}\left[Z_{1}+Z_{3}+Z_{5}+Z_{7}\right]
#
# .. math::
#   \hat{\boldsymbol{y}}=\left(\left\langle O_{\circ}\right\rangle,\left\langle O_{-}\right\rangle,\left\langle O_{\times}\right\rangle\right)
#


######################################################################
# This is the quantum encoding of the symmetries into a learning problem.
# A prediction for a given data point will be obtained by selecting the
# class for which the observed expectation value is the largest.


######################################################################
# Now that we have a specific encoding and have decided on our observables
# we need to choose a suitable cost function to optimise.
# We will use an :math:`l_2` loss function acting on pairs of games and
# labels :math:`D={(g,y)}`, where :math:`D` is our dataset.
#


######################################################################
# .. :math:
#   \mathcal{L}(\mathcal{D})=\frac{1}{|\mathcal{D}|} \sum_{(\boldsymbol{g}, \boldsymbol{y}) \in \mathcal{D}}\|\hat{\boldsymbol{y}}(\boldsymbol{g})-\boldsymbol{y}\|_{2}^{2}
#


######################################################################
# Let's now implement this!
# 
# First let's generate some games.
# Here we are creating a small program that will play Noughts and Crosses against itself in a random fashion.
# On completion, it spits out the winner and the winning board, with noughts as +1, draw as 0, and crosses as -1.
# There are 26,830 different possible games but we will only sample a few hundred.




# Fix seeds for reproducability




#  create an empty board




# Check for empty places on board









# Select a random place for the player







# Check if there is a winner by having 3 in a row

















# Check if there is a winner by having 3 in a column














# Check if there is a winner by having 3 along a diagonal














# Check if the win conditions have been met or if a draw has occurred












# Main function to start the game































# Create datasets but with even numbers of each outcome





######################################################################
# Now let's create the relevant circuit expectation values that respect
# the symmetry classes we defined over the single-site and two-site measurements.





# Set up a nine-qubit system






# Now let's encode the data in the following qubit models, first with symmetry



































































######################################################################
# Let's also look at the same series of gates but this time they
# are applied independently from one another, so we won't be preserving
# the symmetries with our gate operations. Practically this also means
# more parameters, as previously groups of gates were updated together.











































































######################################################################
# Note again how, though these circuits have a similar form to before, they are parameterised differently.
# We need to feed the vector :math:`\boldsymbol{y}` made up of the expectation value of these
# three operators into the loss function and use this to update our
# parameters.
















######################################################################
# Recall that the loss function we're interested in is
# :math:`\mathcal{L}(\mathcal{D})=\frac{1}{|\mathcal{D}|} \sum_{(\boldsymbol{g}, \boldsymbol{y}) \in \mathcal{D}}\|\hat{\boldsymbol{y}}(\boldsymbol{g})-\boldsymbol{y}\|_{2}^{2}`.
# We need to define this and then we can begin our optimisation.

# calculate the mean square error for this classification problem







######################################################################
# Let's now train our symmetry-preserving circuit on the data.


































































######################################################################
# Now we train the non-symmetry preserving circuit.






# calculate mean square error for this classification problem

































































######################################################################
# Finally let's plot the results and see how the two training regimes differ.













######################################################################
# What we can see then is that by paying attention to the symmetries intrinsic
# to the learning problem and reflecting this in an equivariant gate set
# we have managed to improve our learning accuracies, while also using fewer parameters.
# While the symmetry-aware circuit clearly outperforms the naive one, it is notable however that
# the learning accuracies in both cases are hardly ideal given this is a solved game.
# So paying attention to symmetries definitely helps, but it also isn't a magic bullet!
#

######################################################################
# The use of symmetries in both quantum and classical machine learning is a developing field, so we
# can expect new results to emerge over the coming years. If you want to get
# involved, the references given below are a great place to start.


##############################################################################
# References
# ----------
#
# .. [#Bronstein2021]
#
#   Michael M. Bronstein, Joan Bruna, Taco Cohen, Petar Veličković (2021).
#   Geometric Deep Learning: Grids, Groups, Graphs, Geodesics, and Gauges.
#   `arXiv:2104.13478 <https://arxiv.org/abs/2104.13478>`__
#
# .. [#Nguyen2022]
#
#   Quynh T. Nguyen, Louis Schatzki, Paolo Braccia, Michael Ragone,
#   Patrick J. Coles, Frédéric Sauvage, Martín Larocca, and M. Cerezo (2022).
#   Theory for Equivariant Quantum Neural Networks.
#   `arXiv:2210.08566 <https://arxiv.org/abs/2210.08566>`__
#
# .. [#Meyer2022]
#
#   Johannes Jakob Meyer, Marian Mularski, Elies Gil-Fuster, Antonio Anna Mele,
#   Francesco Arzani, Alissa Wilms, Jens Eisert (2022).
#   Exploiting symmetry in variational quantum machine learning.
#   `arXiv:2205.06217 <https://arxiv.org/abs/2205.06217>`__
#


##############################################################################
# Acknowledgments
# ---------------
#
# The author would also like to acknowledge the helpful input of C.-Y. Park.
#

##############################################################################
# About the author
# ----------------
# .. include:: ../_static/authors/richard_east.txt
