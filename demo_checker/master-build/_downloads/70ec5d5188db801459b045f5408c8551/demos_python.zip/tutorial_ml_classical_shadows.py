r"""
Machine learning for quantum many-body problems
==============================================================

.. meta::
    :property="og:description": Machine learning for many-body problems
    :property="og:image": https://pennylane.ai/qml/_images/ml_classical_shadow.png

.. related::
    tutorial_classical_shadows Classical Shadows
    tutorial_kernel_based_training Kernel-based training with scikit-learn
    tutorial_kernels_module Training and evaluating quantum kernels


*Author: Utkarsh Azad — Posted: 02 May 2022. Last Updated: 09 May 2022*


Storing and processing a complete description of an :math:`n`-qubit quantum mechanical
system is challenging because the amount of memory required generally scales exponentially
with the number of qubits. The quantum community has recently addressed this challenge by using
the :doc:`classical shadow <tutorial_classical_shadows>` formalism, which allows us to build more concise classical descriptions
of quantum states using randomized single-qubit measurements. It was argued in Ref. [#preskill]_
that combining classical shadows with classical machine learning enables using learning models
that efficiently predict properties of the quantum systems, such as the expectation value of a
Hamiltonian, correlation functions, and entanglement entropies.

.. figure:: /demonstrations/ml_classical_shadows/class_shadow_ml.png
   :align: center
   :width: 80 %
   :alt: Combining ML with Classical Shadow

   Combining machine learning and classical shadows


In this demo, we describe one of the ideas presented in Ref. [#preskill]_ for using classical
shadow formalism and machine learning to predict the ground-state properties of the
2D antiferromagnetic Heisenberg model. We begin by learning how to build the Heisenberg model,
calculate its ground-state properties, and compute its classical shadow. Finally, we demonstrate
how to use :doc:`kernel-based learning models <tutorial_kernels_module>` to predict ground-state properties from the learned
classical shadows. So let's get started!

Building the 2D Heisenberg Model
---------------------------------

We define a two-dimensional antiferromagnetic `Heisenberg model
<https://en.wikipedia.org/wiki/Quantum_Heisenberg_model>`__ as a square
lattice, where a spin-1/2 particle occupies each site. The antiferromagnetic
nature and the overall physics of this model depend on the couplings
:math:`J_{ij}` present between the spins, as reflected in the Hamiltonian
associated with the model:

.. math::  H = \sum_{i < j} J_{ij}(X_i X_j + Y_i Y_j + Z_i Z_j) .

Here, we consider the family of Hamiltonians where all the couplings :math:`J_{ij}`
are sampled uniformly from [0, 2]. We build a coupling matrix :math:`J` by providing
the number of rows :math:`N_r` and columns :math:`N_c` present in the square lattice.
The dimensions of this matrix are :math:`N_s \times N_s`, where :math:`N_s = N_r \times N_c`
is the total number of spin particles present in the model.


"""



















######################################################################
# For this demo, we study a model with four spins arranged on the nodes of
# a square lattice. We require four qubits for simulating this model;
# one qubit for each spin. We start by building a coupling matrix ``J_mat``
# using our previously defined function.
#






######################################################################
# We can now visualize the model instance by representing the coupling matrix as a
# ``networkx`` graph:


















######################################################################
# We then use the same coupling matrix ``J_mat`` to obtain the Hamiltonian
# :math:`H` for the model we have instantiated above.
#


















######################################################################
# For the Heisenberg model, a property of interest is usually the two-body
# correlation function :math:`C_{ij}`, which for a pair of spins :math:`i`
# and :math:`j` is defined as the following operator:
#
# .. math::  \hat{C}_{ij} = \frac{1}{3} (X_i X_j + Y_iY_j + Z_iZ_j).










######################################################################
#
# The expectation value of each such operator :math:`\hat{C}_{ij}` with respect to
# the ground state :math:`|\psi_{0}\rangle` of the model can be used to build
# the correlation matrix :math:`C`:
#
# .. math:: {C}_{ij} = \langle \hat{C}_{ij} \rangle = \frac{1}{3} \langle \psi_{0} | X_i X_j + Y_iY_j + Z_iZ_j | \psi_{0} \rangle .
#

######################################################################
# Hence, to build :math:`C` for the model, we need to calculate its
# ground state :math:`|\psi_{0}\rangle`. We do this by diagonalizing
# the Hamiltonian for the model. Then, we obtain the eigenvector corresponding
# to the smallest eigenvalue.
#








######################################################################
# We then build a circuit that initializes the qubits into the ground
# state and measures the expectation value of the provided set of observables.
#











######################################################################
# Finally, we execute this circuit to obtain the exact correlation matrix
# :math:`C`. We compute the correlation operators :math:`\hat{C}_{ij}` and
# their expectation values with respect to the ground state :math:`|\psi_0\rangle`.
#



















#########################################################################
# Once built, we can visualize the correlation matrix:
#















######################################################################
# Constructing Classical Shadows
# ------------------------------
#


######################################################################
# Now that we have built the Heisenberg model, the next step is to construct
# a :doc:`classical shadow <tutorial_classical_shadows>` representation for its ground state. To construct an
# approximate classical representation of an :math:`n`-qubit quantum state :math:`\rho`,
# we perform randomized single-qubit measurements on :math:`T`-copies of
# :math:`\rho`. Each measurement is chosen randomly among the Pauli bases
# :math:`X`, :math:`Y`, or :math:`Z` to yield random :math:`n` pure product
# states :math:`|s_i\rangle` for each copy:
#
# .. math:: |s_{i}^{(t)}\rangle \in \{|0\rangle, |1\rangle, |+\rangle, |-\rangle, |i+\rangle, |i-\rangle\}.
#
# .. math::  S_T(\rho) = \big\{|s_{i}^{(t)}\rangle: i\in\{1,\ldots, n\},\ t\in\{1,\ldots, T\} \big\}.
#
# Each of the :math:`|s_i^{(t)}\rangle` provides us with a snapshot of the
# state :math:`\rho`, and the :math:`nT` measurements yield the complete
# set :math:`S_{T}`, which requires just :math:`3nT` bits to be stored
# in classical memory. This is discussed in further detail in our previous
# demo about :doc:`classical shadows <tutorial_classical_shadows>`.
#

######################################################################
# .. figure::  /demonstrations/ml_classical_shadows/class_shadow_prep.png
#    :align: center
#    :width: 100 %
#    :alt: Preparing Classical Shadows
#


######################################################################
# To prepare a classical shadow for the ground state of the Heisenberg
# model, we simply reuse the circuit template used above and reconstruct
# a ``QNode`` utilizing a device that performs single-shot measurements.
#





######################################################################
# Now, we define a function to build the classical shadow for the quantum
# state prepared by a given :math:`n`-qubit circuit using :math:`T`-copies
# of randomized Pauli basis measurements
#























######################################################################
# Furthermore, :math:`S_{T}` can be used to construct an approximation
# of the underlying :math:`n`-qubit state :math:`\rho` by averaging over :math:`\sigma_t`:
#
# .. math::  \sigma_T(\rho) = \frac{1}{T} \sum_{1}^{T} \big(3|s_{1}^{(t)}\rangle\langle s_1^{(t)}| - \mathbb{I}\big)\otimes \ldots \otimes \big(3|s_{n}^{(t)}\rangle\langle s_n^{(t)}| - \mathbb{I}\big).
#

































######################################################################
# To see how well the reconstruction works for different values of :math:`T`,
# we look at the `fidelity <https://en.wikipedia.org/wiki/Fidelity_of_quantum_states>`_
# of the actual quantum state with respect to the reconstructed quantum state from
# the classical shadow with :math:`T` copies. On average, as the number of copies
# :math:`T` is increased, the reconstruction becomes more effective with average
# higher fidelity values (orange) and lower variance (blue). Eventually, in the
# limit :math:`T\rightarrow\infty`, the reconstruction will be exact.
#
# .. figure:: /demonstrations/ml_classical_shadows/fidel_snapshot.png
#    :align: center
#    :width: 80 %
#    :alt: Fidelity of reconstructed ground state with different shadow sizes :math:`T`
#
#    Fidelity of the reconstructed ground state with different shadow sizes :math:`T`
#


######################################################################
# The reconstructed quantum state :math:`\sigma_T` can also be used to
# evaluate expectation values :math:`\text{Tr}(O\sigma_T)` for some localized
# observable :math:`O = \bigotimes_{i}^{n} P_i`, where :math:`P_i \in \{I, X, Y, Z\}`.
# However, as shown above, :math:`\sigma_T` would be only an approximation of
# :math:`\rho` for finite values of :math:`T`. Therefore, to estimate
# :math:`\langle O \rangle` robustly, we use the median of means
# estimation. For this purpose, we split up the :math:`T` shadows into
# :math:`K` equally-sized groups and evaluate the median of the mean
# value of :math:`\langle O \rangle` for each of these groups.
#

































######################################################################
# Now we estimate the correlation matrix :math:`C^{\prime}` from the
# classical shadow approximation of the ground state.
#






















#########################################################################
# This time, let us visualize the deviation observed between the exact correlation
# matrix (:math:`C`) and the estimated correlation matrix (:math:`C^{\prime}`)
# to assess the effectiveness of classical shadow formalism.
#















######################################################################
# Training Classical Machine Learning Models
# ------------------------------------------
#


######################################################################
# There are multiple ways in which we can combine classical shadows and
# machine learning. This could include training a model to learn
# the classical representation of quantum systems based on some system
# parameter, estimating a property from such learned classical representations,
# or a combination of both. In our case, we consider the problem of using
# :doc:`kernel-based models <tutorial_kernel_based_training>` to learn the ground-state representation of the
# Heisenberg model Hamiltonian :math:`H(x_l)` from the coupling vector :math:`x_l`,
# where :math:`x_l = [J_{i,j} \text{ for } i < j]`. The goal is to predict the
# correlation functions :math:`C_{ij}`:
#
# .. math::  \big\{x_l \rightarrow \sigma_T(\rho(x_l)) \rightarrow \text{Tr}(\hat{C}_{ij} \sigma_T(\rho(x_l))) \big\}_{l=1}^{N}.
#
# Here, we consider the following kernel-based machine learning model [#neurtangkernel]_:
#
# .. math::  \hat{\sigma}_{N} (x) = \sum_{l=1}^{N} \kappa(x, x_l)\sigma_T (x_l) = \sum_{l=1}^{N} \left(\sum_{l^{\prime}=1}^{N} k(x, x_{l^{\prime}})(K+\lambda I)^{-1}_{l, l^{\prime}} \sigma_T(x_l) \right),
#
# where :math:`\lambda > 0` is a regularization parameter in cases when
# :math:`K` is not invertible, :math:`\sigma_T(x_l)` denotes the classical
# representation of the ground state :math:`\rho(x_l)` of the Heisenberg
# model constructed using :math:`T` randomized Pauli measurements, and
# :math:`K_{ij}=k(x_i, x_j)` is the kernel matrix with
# :math:`k(x, x^{\prime})` as the kernel function.
#
# Similarly, estimating an expectation value on the predicted ground state
# :math:`\sigma_T(x_l)` using the trained model can then be done by
# evaluating:
#
# .. math::  \text{Tr}(\hat{O} \hat{\sigma}_{N} (x)) = \sum_{l=1}^{N} \kappa(x, x_l)\text{Tr}(O\sigma_T (x_l)).
#
# We train the classical kernel-based models using :math:`N = 70`
# randomly chosen values of the coupling matrices :math:`J`.
#

# imports for ML methods and techniques




######################################################################
# First, to build the dataset, we use the function ``build_dataset`` that
# takes as input the size of the dataset (``num_points``), the topology of
# the lattice (``Nr`` and ``Nc``), and the number of randomized
# Pauli measurements (:math:`T`) for the construction of classical shadows.
# The ``X_data`` is the set of coupling vectors that are defined as a
# stripped version of the coupling matrix :math:`J`, where only non-duplicate
# and non-zero :math:`J_{ij}` are considered. The ``y_exact`` and
# ``y_clean`` are the set of correlation vectors, i.e., the flattened
# correlation matrix :math:`C`, computed with respect to the ground-state
# obtained from exact diagonalization and classical shadow representation
# (with :math:`T=500`), respectively.
#






































######################################################################
# Now that our dataset is ready, we can shift our focus to the ML models.
# Here, we use two different Kernel functions: (i) Gaussian Kernel and
# (ii) Neural Tangent Kernel. For both of them, we consider the
# regularization parameter :math:`\lambda` from the following set of values:
#
# .. math::  \lambda = \left\{ 0.0025, 0.0125, 0.025, 0.05, 0.125, 0.25, 0.5, 1.0, 5.0, 10.0 \right\}.
#
# Next, we define the kernel functions :math:`k(x, x^{\prime})` for each
# of the mentioned kernels:

######################################################################
# .. math::  k(x, x^{\prime}) = e^{-\gamma||x - x^{\prime}||^{2}_{2}}. \tag{Gaussian Kernel}
#
# For the Gaussian kernel, the hyperparameter
# :math:`\gamma = N^{2}/\sum_{i=1}^{N} \sum_{j=1}^{N} ||x_i-x_j||^{2}_{2} > 0`
# is chosen to be the inverse of the average Euclidean distance
# :math:`x_i` and :math:`x_j`. The kernel is implemented using the
# radial-basis function (rbf) kernel in the ``sklearn`` library.
#

######################################################################
# .. math::  k(x, x^{\prime}) = k^{\text{NTK}}(x, x^{\prime}). \tag{Neural Tangent Kernel}
#
# The neural tangent kernel :math:`k^{\text{NTK}}` used here is equivalent
# to an infinite-width feed-forward neural network with four hidden
# layers and that uses the rectified linear unit (ReLU) as the activation
# function. This is implemented using the ``neural_tangents`` library.
#




















######################################################################
# For the above two defined kernel methods, we obtain the best learning
# model by performing hyperparameter tuning using cross-validation for
# the prediction task of each :math:`C_{ij}`. For this purpose, we
# implement the function ``fit_predict_data``, which takes input as the
# correlation function index ``cij``, kernel matrix ``kernel``, and internal
# kernel mapping ``opt`` required by the kernel-based regression models
# from the ``sklearn`` library.
#















































######################################################################
# We perform the fitting and prediction for each :math:`C_{ij}` and print
# the output in a tabular format.
#














# For each C_ij print (best_cv_score, test_score) pair












######################################################################
# Overall, we find that the models with the Gaussian kernel performed
# better than those with NTK for predicting the expectation value
# of the correlation function :math:`C_{ij}` for the ground state of
# the Heisenberg model. However, the best choice of :math:`\lambda`
# differed substantially across the different :math:`C_{ij}` for both
# kernels. We present the predicted correlation matrix :math:`C^{\prime}`
# for randomly selected Heisenberg models from the test set below for
# comparison against the actual correlation matrix :math:`C`, which is
# obtained from the ground state found using exact diagonalization.
#





































######################################################################
# Finally, we also attempt to showcase the effect of the size of training data
# :math:`N` and the number of Pauli measurements :math:`T`. For this, we look
# at the average root-mean-square error (RMSE) in prediction for each kernel
# over all two-point correlation functions :math:`C_{ij}`. Here, the first
# plot looks at the different training sizes :math:`N` with a fixed number of
# randomized Pauli measurements :math:`T=100`. In contrast, the second plot
# looks at the different shadow sizes :math:`T` with a fixed training data size
# :math:`N=70`. The performance improvement seems to be saturating after a
# sufficient increase in :math:`N` and :math:`T` values for all two kernels
# in both the cases.
#

######################################################################
# .. image::  /demonstrations/ml_classical_shadows/rmse_training.png
#     :width: 47 %
#
# .. image::  /demonstrations/ml_classical_shadows/rmse_shadow.png
#     :width: 47 %
#

######################################################################
# Conclusion
# ----------
#
# This demo illustrates how classical machine learning models can benefit from
# the classical shadow formalism for learning characteristics and predicting
# the behavior of quantum systems. As argued in Ref. [#preskill]_, this raises
# the possibility that models trained on experimental or quantum data data can
# effectively address quantum many-body problems that cannot be solved using
# classical methods alone.
#

######################################################################
# .. _ml_classical_shadow_references:
#
# References
# ----------
#
# .. [#preskill]
#
#    H. Y. Huang, R. Kueng, G. Torlai, V. V. Albert, J. Preskill, "Provably
#    efficient machine learning for quantum many-body problems",
#    `arXiv:2106.12627 [quant-ph] <https://arxiv.org/abs/2106.12627>`__ (2021)
#
# .. [#neurtangkernel]
#
#    A. Jacot, F. Gabriel, and C. Hongler. "Neural tangent kernel:
#    Convergence and generalization in neural networks". `NeurIPS, 8571–8580
#    <https://proceedings.neurips.cc/paper/2018/file/5a4be1fa34e62bb8a6ec6b91d2462f5a-Paper.pdf>`__ (2018)
#
#
# About the author
# ----------------
# .. include:: ../_static/authors/utkarsh_azad.txt
