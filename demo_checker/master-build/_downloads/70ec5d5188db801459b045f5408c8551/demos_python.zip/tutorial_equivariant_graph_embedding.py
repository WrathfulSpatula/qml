r"""
An equivariant graph embedding
==============================

.. meta::
    :property="og:description": Find out more about how to embedd graphs into quantum states.
    :property="og:image": https://pennylane.ai/qml/_images/thumbnail_tutorial_equivariant_graph_embedding.png

.. related::
   tutorial_geometric_qml Geometric quantum machine learning
"""

######################################################################
# A notorious problem when data comes in the form of graphs -- think of molecules or social media
# networks -- is that the numerical representation of a graph in a computer is not unique. 
# For example, if we describe a graph via an `adjacency matrix <https://en.wikipedia.org/wiki/Adjacency_matrix>`_ whose
# entries contain the edge weights as off-diagonals and node weights on the diagonal, 
# any simultaneous permutation of rows and columns of this matrix refer to the same graph. 
# 
# .. figure:: ../demonstrations/equivariant_graph_embedding/adjacency-matrices.png
#    :width: 60%
#    :align: center
#    :alt: adjacency-matrices
#
# For example, the graph in the image above is represented by each of the two equivalent adjacency matrices. 
# The top matrix can be transformed into the bottom matrix 
# by swapping the first row with the third row, then swapping the third column with the third column, then the  
# new first row with the second, and finally the first colum with the second.
#
# But the number of such permutations grows factorially with the number of nodes in the graph, which 
# is even worse than an exponential growth!
#    
# If we want computers to learn from graph data, we usually want our models to "know" that all these
# permuted adjacency matrices refer to the same object, so we do not waste resources on learning 
# this property. In mathematical terms, this means that the model should be in- or 
# equivariant (more about this distinction below) with respect to permutations. 
# This is the basic motivation of `Geometric Deep Learning <https://geometricdeeplearning.com/>`_, 
# ideas of which have found their way into quantum machine learning. 
# 
# This tutorial shows how to implement an example of a trainable permutation equivariant graph embedding 
# as proposed in `Skolik et al. (2022) <https://arxiv.org/pdf/2205.06109.pdf>`_. The embedding 
# maps the adjacency matrix of an undirected graph with edge and node weights to a quantum state, such that 
# permutations of an adjacency matrix get mapped to the same states *if only we also 
# permute the qubit registers in the same fashion*.
# 
# .. note:: 
#    The tutorial is meant for beginners and does not contain the mathematical details of the 
#    rich theory of equivariance. Have a look
#    `at this demo <https://pennylane.ai/qml/demos/tutorial_geometric_qml.html>`_ if you want to know more. 
# 
# 
# Permuted adjacency matrices describe the same graph
# ---------------------------------------------------
# 
# Let us first verify that permuted adjacency matrices really describe one and the same graph. 
# We also gain some useful data generation functions for later.
#
# First we create random adjacency matrices. 
# The entry :math:`a_{ij}` of this matrix corresponds to the weight of the edge between nodes 
# :math:`i` and :math:`j` in the graph. We assume that graphs have no self-loops; instead, 
# the diagonal elements of the adjacency matrix are interpreted as node weights (or 
# "node attributes"). 
# 
# Taking the example of a Twitter user retweet network, the nodes would be users, 
# edge weights indicate how often two users retweet each other and node attributes 
# could indicate the follower count of a user.
#


















######################################################################
# Let's also write a function to generate permuted versions of this adjacency matrix.
#
















######################################################################
# If we create `networkx` graphs from both adjacency matrices and plot them, 
# we see that they are identical as claimed.
#



# interpret diagonal of matrix as node attributes









# interpret diagonal of permuted matrix as node attributes














######################################################################
# .. note:: 
# 
#     The issue of non-unique numerical representations of graphs ultimately stems 
#     from the fact that the nodes in a graph 
#     do not have an intrinsic order, and by labelling them in a numerical data structure like a matrix
#     we therefore impose an arbitrary order.
#
# Permutation equivariant embeddings
# ----------------------------------
# 
# When we design a machine learning model that takes graph data, the first step is to encode 
# the adjacency matrix into a quantum state using an embedding or 
# `quantum feature map <https://pennylane.ai/qml/glossary/quantum_feature_map.html>`_
# :math:`\phi`:
# 
# .. math:: 
# 
#     A \rightarrow |\phi(A)\rangle .
# 
# We may want the resulting quantum state to be the same for all adjacency matrices describing 
# the same graph. In mathematical terms, this means that :math:`\phi` is an *invariant* embedding with respect to 
# simultaneous row and column permutations :math:`\pi(A)` of the adjacency matrix:
# 
# .. math:: 
# 
#     |\phi(A) \rangle = |\phi(\pi(A))\rangle \;\; \text{ for all } \pi .
# 
# However, invariance is often too strong a constraint. Think for example of an encoding that 
# associates each node in the graph with a qubit. We might want permutations of the adjacency 
# matrix to lead to the same state *up to an equivalent permutation of the qubits* :math:`P_{\pi}`,
# where
#
# .. math:: 
#    
#     P_{\pi} |q_1,...,q_n \rangle = |q_{\textit{perm}_{\pi}(1)}, ... q_{\textit{perm}_{\pi}(n)} \rangle .
# 
# The function :math:`\text{perm}_{\pi}` maps each index to the permuted index according to :math:`\pi`. 
#    
#
# .. note:: 
#
#     The operator :math:`P_{\pi}` is implemented by PennyLane's :class:`~pennylane.Permute`.
# 
# This results in an *equivariant* embedding with respect to permutations of the adjacency matrix:
# 
# .. math:: 
# 
#     |\phi(A) \rangle = P_{\pi}|\phi(\pi(A))\rangle \;\; \text{ for all } \pi . 
#     
#  
# This is exactly what the following quantum embedding is aiming to do! The mathematical details
# behind these concepts use group theory and are beautiful, but can be a bit daunting. 
# Have a look at `this paper <https://arxiv.org/abs/2210.08566>`_ if you want to learn more.
# 
#
# Implementation in PennyLane
# ---------------------------
# 
# Let's get our hands dirty with an example. As mentioned, we will implement the permutation-equivariant 
# embedding suggested in `Skolik et al. (2022) <https://arxiv.org/pdf/2205.06109.pdf>`_ which has this structure:
# 
# .. figure:: ../demonstrations/equivariant_graph_embedding/circuit.png
#    :width: 70%
#    :align: center
#    :alt: Equivariant embedding
#    
# The image can be found in `Skolik et al. (2022) <https://arxiv.org/pdf/2205.06109.pdf>`_ and shows one layer of the circuit.  
# The :math:`\epsilon` are our edge weights while :math:`\alpha` describe the node weights, and the :math:`\beta`, :math:`\gamma` are variational parameters.
#
# In PennyLane this looks as follows:
#






























######################################################################
# We can use this ansatz in a circuit. 























######################################################################
# Validating the equivariance
# ---------------------------
# 
# Let's now check if the circuit is really equivariant!
# 
# This is the expectation value we get using the original adjacency matrix as an input:
#





######################################################################
# If we permute the adjacency matrix, this is what we get:
#







######################################################################
# Why are the two values different? Well, we constructed an *equivariant* ansatz, 
# not an *invariant* one! Remember, an *invariant* ansatz means that embedding a permutation of 
# the adjacency matrix leads to the same state as an embedding of the original matrix. 
# An *equivariant* ansatz embeds the permuted adjacency matrix into a state where the qubits 
# are permuted as well. 
#
# As a result, the final state before measurement is only the same if we 
# permute the qubits in the same manner that we permute the input adjacency matrix. We could insert a 
# permutation operator ``qml.Permute(perm)`` to achieve this, or we simply permute the wires 
# of the observables!
#



######################################################################
# Now everything should work out!
#




######################################################################
# Et voilà!
# 
# 
# Conclusion
# ----------
# 
# Equivariant graph embeddings can be combined with other equivariant parts of a quantum machine learning pipeline 
# (like measurements and the cost function). `Skolik et al. (2022) <https://arxiv.org/pdf/2205.06109.pdf>`_, 
# for example, use such a pipeline as part of a reinforcement learning scheme that finds heuristic solutions for the 
# traveling salesman problem. Their simulations compare a fully equivariant model to circuits that break 
# permutation equivariance and show that it performs better, confirming that if we know 
# about structure in our data, we should try to use this knowledge in machine learning.
#
# References
# ----------
#
# 1. Andrea Skolik, Michele Cattelan, Sheir Yarkoni,Thomas Baeck and Vedran Dunjko (2022). 
#    Equivariant quantum circuits for learning on weighted graphs. 
#    `arXiv:2205.06109 <https://arxiv.org/abs/2205.06109>`__
#
# 2. Quynh T. Nguyen, Louis Schatzki, Paolo Braccia, Michael Ragone,
#    Patrick J. Coles, Frédéric Sauvage, Martín Larocca and Marco Cerezo (2022).
#    Theory for Equivariant Quantum Neural Networks.
#    `arXiv:2210.08566 <https://arxiv.org/abs/2210.08566>`__
# 
# About the author 
# -------------------------
# .. include:: ../_static/authors/maria_schuld.txt




