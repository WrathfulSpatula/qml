"""
Turning quantum nodes into Keras Layers
=======================================

.. meta::
    :property="og:description": Learn how to create hybrid ML models in PennyLane using Keras
    :property="og:image": https://pennylane.ai/qml/_images/Keras_logo.png

.. related::

   tutorial_qnn_module_torch Turning quantum nodes into Torch Layers

*Author: Tom Bromley — Posted: 02 November 2020. Last updated: 28 January 2021.*

Creating neural networks in `Keras <https://keras.io/>`__ is easy. Models are constructed from
elementary *layers* and can be trained using a high-level API. For example, the following code
defines a two-layer network that could be used for binary classification:
"""











###############################################################################
# The model can then be trained using `model.fit()
# <https://www.tensorflow.org/api_docs/python/tf/keras/Model#fit>`__.
#
# **What if we want to add a quantum layer to our model?** This is possible in PennyLane:
# :doc:`QNodes <../glossary/hybrid_computation>` can be converted into Keras layers and combined
# with the wide range of built-in classical
# `layers <https://www.tensorflow.org/api_docs/python/tf/keras/layers>`__ to create truly hybrid
# models. This tutorial will guide you through a simple example to show you how it's done!
#
# .. note::
#
#     A similar demo explaining how to
#     :doc:`turn quantum nodes into Torch layers <tutorial_qnn_module_torch>`
#     is also available.
#
# Fixing the dataset and problem
# ------------------------------
#
# Let us begin by choosing a simple dataset and problem to allow us to focus on how the hybrid
# model is constructed. Our objective is to classify points generated from scikit-learn's
# binary-class
# `make_moons() <https://scikit-learn.org/stable/modules/generated/sklearn.datasets.make_moons.html>`__ dataset:





# Set random seeds











###############################################################################
# Defining a QNode
# ----------------
#
# Our next step is to define the QNode that we want to interface with Keras. Any combination of
# device, operations and measurements that is valid in PennyLane can be used to compose the
# QNode. However, the QNode arguments must satisfy additional :doc:`conditions
# <code/api/pennylane.qnn.KerasLayer>` including having an argument called ``inputs``. All other
# arguments must be arrays or tensors and are treated as trainable weights in the model. We fix a
# two-qubit QNode using the
# :doc:`default.qubit <code/api/pennylane.devices.default_qubit.DefaultQubit>` simulator and
# operations from the :doc:`templates <introduction/templates>` module.












###############################################################################
# Interfacing with Keras
# ----------------------
#
# With the QNode defined, we are ready to interface with Keras. This is achieved using the
# :class:`~pennylane.qnn.KerasLayer` class of the :mod:`~pennylane.qnn` module, which converts the
# QNode to the elementary building block of Keras: a *layer*. We shall see in the following how the
# resultant layer can be combined with other well-known neural network layers to form a hybrid
# model.
#
# We must first define the ``weight_shapes`` dictionary. Recall that all of
# the arguments of the QNode (except the one named ``inputs``) are treated as trainable
# weights. For the QNode to be successfully converted to a layer in Keras, we need to provide the
# details of the shape of each trainable weight for them to be initialized. The ``weight_shapes``
# dictionary maps from the argument names of the QNode to corresponding shapes:




###############################################################################
# In our example, the ``weights`` argument of the QNode is trainable and has shape given by
# ``(n_layers, n_qubits)``, which is passed to
# :func:`~pennylane.templates.layers.BasicEntanglerLayers`.
#
# Now that ``weight_shapes`` is defined, it is easy to then convert the QNode:



###############################################################################
# With this done, the QNode can now be treated just like any other Keras layer and we can proceed
# using the familiar Keras workflow.
#
# Creating a hybrid model
# -----------------------
#
# Let's create a basic three-layered hybrid model consisting of:
#
# 1. a 2-neuron fully connected classical layer
# 2. our 2-qubit QNode converted into a layer
# 3. another 2-neuron fully connected classical layer
# 4. a softmax activation to convert to a probability vector
#
# A diagram of the model can be seen in the figure below.
#
# .. figure:: /demonstrations/qnn_module/qnn_keras.png
#    :width: 100%
#    :align: center
#
# We can construct the model using the
# `Sequential <https://www.tensorflow.org/api_docs/python/tf/keras/Sequential>`__ API:





###############################################################################
# Training the model
# ------------------
#
# We can now train our hybrid model on the classification dataset using the usual Keras
# approach. We'll use the
# standard `SGD <https://www.tensorflow.org/api_docs/python/tf/keras/optimizers/SGD>`__ optimizer
# and the mean absolute error loss function:




###############################################################################
# Note that there are more advanced combinations of optimizer and loss function, but here we are
# focusing on the basics.
#
# The model is now ready to be trained!



###############################################################################
# How did we do? The model looks to have successfully trained and the accuracy on both the
# training and validation datasets is reasonably high. In practice, we would aim to push the
# accuracy higher by thinking carefully about the model design and the choice of hyperparameters
# such as the learning rate.
#
# Creating non-sequential models
# ------------------------------
#
# The model we created above was composed of a sequence of classical and quantum layers. This
# type of model is very common and is suitable in a lot of situations. However, in some cases we
# may want a greater degree of control over how the model is constructed, for example when we
# have multiple inputs and outputs or when we want to distribute the output of one layer into
# multiple subsequent layers.
#
# Suppose we want to make a hybrid model consisting of:
#
# 1. a 4-neuron fully connected classical layer
# 2. a 2-qubit quantum layer connected to the first two neurons of the previous classical layer
# 3. a 2-qubit quantum layer connected to the second two neurons of the previous classical layer
# 4. a 2-neuron fully connected classical layer which takes a 4-dimensional input from the
#    combination of the previous quantum layers
# 5. a softmax activation to convert to a probability vector
#
# A diagram of the model can be seen in the figure below.
#
# .. figure:: /demonstrations/qnn_module/qnn2_keras.png
#    :width: 100%
#    :align: center
#
# This model can also be constructed using the `Functional API
# <https://keras.io/guides/functional_api/>`__:

# re-define the layers





# construct the model










###############################################################################
# As a final step, let's train the model to check if it's working:






###############################################################################
# Great! We've mastered the basics of constructing hybrid classical-quantum models using
# PennyLane and Keras. Can you think of any interesting hybrid models to construct? How do they
# perform on realistic datasets?

##############################################################################
# About the author
# ----------------
# .. include:: ../_static/authors/thomas_bromley.txt